package com.minus30kg.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Forest = Color(0xFF12352B)
private val Green = Color(0xFF38A879)
private val Pale = Color(0xFFF1F7F3)
private val Ink = Color(0xFF18352C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Minus30KgApp(this) }
    }
}

@Composable
private fun Minus30KgApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("minus30kg", Context.MODE_PRIVATE) }
    var weight by remember { mutableFloatStateOf(prefs.getFloat("weight", 123f)) }
    var water by remember { mutableIntStateOf(prefs.getInt("water", 0)) }
    var calories by remember { mutableIntStateOf(prefs.getInt("calories", 0)) }
    var waist by remember { mutableStateOf(prefs.getString("waist", "") ?: "") }
    var food by remember { mutableStateOf("") }
    var foodCalories by remember { mutableStateOf("") }
    var showFoodDialog by remember { mutableStateOf(false) }
    var showWeightDialog by remember { mutableStateOf(false) }
    var newWeight by remember { mutableStateOf(weight.toString()) }
    var notice by remember { mutableStateOf("") }
    val progress = ((123f - weight) / 30f).coerceIn(0f, 1f)

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Pale, surface = Color.White)) {
        Column(Modifier.fillMaxSize().background(Pale).verticalScroll(rememberScrollState()).padding(18.dp)) {
            Text("МИНУС 30 КГ", color = Forest, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text("Твой путь к 93 кг", color = Ink, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text("Маленькие шаги каждый день 💪", color = Color(0xFF63776D), fontSize = 14.sp)
            Spacer(Modifier.height(18.dp))

            Card(colors = CardDefaults.cardColors(containerColor = Forest), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("ТЕКУЩИЙ ВЕС", color = Color(0xFFB9D8C9), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(String.format("%.1f", weight), color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.width(8.dp)); Text("кг", color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(bottom = 8.dp))
                        Spacer(Modifier.weight(1f))
                        OutlinedButton(onClick = { newWeight = weight.toString(); showWeightDialog = true }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Text("Изменить") }
                    }
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Green, trackColor = Color(0xFF416257))
                    Spacer(Modifier.height(8.dp))
                    Text("Цель 93 кг  •  Осталось ${String.format("%.1f", (weight - 93f).coerceAtLeast(0f))} кг", color = Color.White, fontSize = 14.sp)
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard("🔥", "Калории", "$calories ккал", "Добавить еду", Modifier.weight(1f)) { showFoodDialog = true }
                StatCard("💧", "Вода", "$water / 8", "Стаканов", Modifier.weight(1f)) {
                    water = (water + 1).coerceAtMost(30); prefs.edit().putInt("water", water).apply(); notice = "Стакан воды добавлен"
                }
            }
            Spacer(Modifier.height(14.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("📏 Талия", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Измеряй раз в неделю, в одинаковых условиях.", color = Color.Gray, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = waist, onValueChange = { waist = it; prefs.edit().putString("waist", it).apply() }, label = { Text("Обхват талии, см") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            }
            Spacer(Modifier.height(14.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("🍽️ План на сегодня", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    MealRow("Завтрак", "Яйца, овощи и цельнозерновой хлеб")
                    MealRow("Обед", "Курица или мясо, гречка и салат")
                    MealRow("Перекус", "Фрукт и натуральный йогурт")
                    MealRow("Ужин", "Рыба или курица с овощами")
                    Text("Порции подбирай по аппетиту и дневной калорийности; меню — пример, а не медицинское назначение.", color = Color.Gray, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE1F1E7)), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("🚶 Задача дня", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Начни с комфортной прогулки 15–20 минут. Увеличивай нагрузку постепенно.", color = Ink, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Совет: взвешивайся утром в похожих условиях. Ориентируйся на тенденцию за несколько недель.", color = Color(0xFF4D665A), fontSize = 13.sp)
                }
            }
            if (notice.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(notice, color = Green) }
            Spacer(Modifier.height(18.dp))
            Text("Важно: перед интенсивными тренировками проверь давление и уровень сахара. Безопасный темп похудения обычно около 0,5–1 кг в неделю. При заболеваниях согласуй план с врачом.", color = Color(0xFF6C7B73), fontSize = 12.sp)
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showWeightDialog) {
        AlertDialog(onDismissRequest = { showWeightDialog = false }, title = { Text("Записать вес") }, text = {
            OutlinedTextField(value = newWeight, onValueChange = { newWeight = it }, label = { Text("Вес в кг") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
        }, confirmButton = { TextButton(onClick = {
            newWeight.replace(',', '.').toFloatOrNull()?.takeIf { it in 35f..300f }?.let { weight = it; prefs.edit().putFloat("weight", it).apply(); notice = "Вес сохранён" }
            showWeightDialog = false
        }) { Text("Сохранить") } }, dismissButton = { TextButton(onClick = { showWeightDialog = false }) { Text("Отмена") } })
    }
    if (showFoodDialog) {
        AlertDialog(onDismissRequest = { showFoodDialog = false }, title = { Text("Добавить еду") }, text = {
            Column {
                OutlinedTextField(value = food, onValueChange = { food = it }, label = { Text("Продукт / блюдо") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = foodCalories, onValueChange = { foodCalories = it }, label = { Text("Калории, ккал") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            }
        }, confirmButton = { TextButton(onClick = {
            val c = foodCalories.toIntOrNull()
            if (food.isNotBlank() && c != null && c in 1..5000) { calories += c; prefs.edit().putInt("calories", calories).apply(); notice = "Добавлено: $food — $c ккал"; food = ""; foodCalories = ""; showFoodDialog = false }
        }) { Text("Добавить") } }, dismissButton = { TextButton(onClick = { showFoodDialog = false }) { Text("Отмена") } })
    }
}

@Composable
private fun StatCard(emoji: String, title: String, value: String, hint: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp), modifier = modifier) {
        Column(Modifier.padding(15.dp).fillMaxWidth()) {
            Text(emoji, fontSize = 23.sp)
            Text(title, color = Color.Gray, fontSize = 13.sp)
            Text(value, color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Button(onClick = onClick, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp), modifier = Modifier.fillMaxWidth()) { Text(hint, fontSize = 12.sp) }
        }
    }
}

@Composable
private fun MealRow(title: String, description: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
        Text("•", color = Green, fontSize = 20.sp, modifier = Modifier.padding(end = 8.dp))
        Column {
            Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(description, color = Color(0xFF65766D), fontSize = 13.sp)
        }
    }
}
